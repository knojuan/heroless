### <Action Name>  
*<AP Cost> | <Requirements or conditions if any, never a skill>*

<Descriptive narrative of what the action represents, its flavor, and how it might appear in-game. Provide enough imagery or context to support immersion and mechanical clarity.>

[<Related Skill>](skills.md#<Related%20Skill>)
- <Step-by-step mechanical instructions for executing the action>
- <Include relevant skill rolls, modifiers, or references to equipment or conditions>
- <Clarify what happens on success, partial success if applicable, and what doesn't happen>

*<Optional mechanical modifiers, situational bonuses/penalties, or usage notes>*