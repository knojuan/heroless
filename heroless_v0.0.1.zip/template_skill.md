### <Skill Name>
*<Short thematic summary of what the skill represents>*

<Brief narrative description of the skill’s scope, applications, and thematic purpose. Highlight how it differs from similar skills if relevant. Emphasize typical use cases and what types of characters might invest in it.>

- Used for actions involving **<types of tasks or challenges>**.
- <Optional clarification or contrast with related skills>.
- Common in **<encounter types or gameplay scenarios>**.

**Example Actions**:  
- *<Action Name>* — <Brief description>  
- *<Action Name>* — <Brief description>  
- *<Action Name>* — <Brief description> 

**Related Actions**:
[<Action Name>](actions.md#<Action-Name>)